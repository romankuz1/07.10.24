﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SecretMessage
{
    public partial class MainWindow : Window
    {
        private string secretPassword = "password123"; // Замените на ваш секретный пароль
        private string secretMessage = "Это секретное сообщение!";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CheckPasswordButton_Click(object sender, RoutedEventArgs e)
        {
            string enteredPassword = PasswordTextBox.Password;

            if (enteredPassword == secretPassword)
            {
                MessageBox.Show(secretMessage, "Секретное сообщение");
            }
            else
            {
                MessageBox.Show("Неверный пароль. Попробуйте снова.", "Ошибка");
                PasswordTextBox.Password = ""; // Очищаем поле ввода пароля
                PasswordTextBox.Focus(); // Переводим фокус на поле ввода пароля
            }
        }
    }
}
