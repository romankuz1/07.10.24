﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CalculatorWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения операндов из текстовых полей
            double operand1 = double.Parse(Operand1TextBox.Text);
            double operand2 = double.Parse(Operand2TextBox.Text);

            // Получаем знак операции из выпадающего списка
            string sign = ((ComboBoxItem)OperationComboBox.SelectedItem).Content.ToString();

            // Используем switch для выбора операции
            switch (sign)
            {
                case "+":
                    ResultTextBlock.Text = $"{operand1} + {operand2} = {operand1 + operand2}";
                    break;
                case "-":
                    ResultTextBlock.Text = $"{operand1} - {operand2} = {operand1 - operand2}";
                    break;
                case "*":
                    ResultTextBlock.Text = $"{operand1} * {operand2} = {operand1 * operand2}";
                    break;
                case "/":
                    if (operand2 == 0)
                    {
                        ResultTextBlock.Text = "Ошибка! Деление на ноль невозможно.";
                    }
                    else
                    {
                        ResultTextBlock.Text = $"{operand1} / {operand2} = {operand1 / operand2}";
                    }
                    break;
                default:
                    ResultTextBlock.Text = "Неверный знак операции.";
                    break;
            }
        }
    }
}
